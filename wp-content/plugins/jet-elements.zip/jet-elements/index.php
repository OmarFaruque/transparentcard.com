<?php
/**
 * Silence is golden
 *
 * @package  jet-elements
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */

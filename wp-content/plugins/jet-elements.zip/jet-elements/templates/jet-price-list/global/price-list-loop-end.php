<?php
/**
 * Price list end template
 */
?>
</ul>
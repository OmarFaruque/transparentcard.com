jQuery(document).ready(function(){
    console.log('document is ready by omar');
});
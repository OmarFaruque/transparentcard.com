<?php
/**
 * Timeline list start template
 */

$settings = $this->get_settings_for_display();
?>
<div class="jet-hor-timeline-list jet-hor-timeline-list--middle">
	<div class="jet-hor-timeline__line"></div>

<?php
/**
 * Registration Form 
 */
echo do_shortcode( '[transparent_registration_form]', false );
?>
